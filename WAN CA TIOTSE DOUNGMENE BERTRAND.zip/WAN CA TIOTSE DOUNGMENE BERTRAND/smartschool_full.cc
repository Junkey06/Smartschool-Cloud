#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/mobility-module.h"
#include "ns3/netanim-module.h"
#include "ns3/flow-monitor-module.h"
#include <fstream>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("SmartSchoolCloud");

int main(int argc, char *argv[])
{
    Time::SetResolution(Time::NS);

    /* =======================
       1. CREATE NODES
    ======================= */
    NodeContainer cloud; cloud.Create(1);
    NodeContainer students; students.Create(5);
    NodeContainer teachers; teachers.Create(3);
    NodeContainer admins; admins.Create(2);
    NodeContainer router; router.Create(1);

    /* =======================
       2. INSTALL INTERNET STACK
    ======================= */
    InternetStackHelper internet;
    internet.InstallAll();

    /* =======================
       3. LINKS
    ======================= */
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
    p2p.SetChannelAttribute("Delay", StringValue("20ms"));

    NetDeviceContainer cloudRouter = p2p.Install(cloud.Get(0), router.Get(0));
    NetDeviceContainer studentRouter;
    for (uint32_t i = 0; i < students.GetN(); i++)
        studentRouter.Add(p2p.Install(students.Get(i), router.Get(0)));
    NetDeviceContainer teacherRouter;
    for (uint32_t i = 0; i < teachers.GetN(); i++)
        teacherRouter.Add(p2p.Install(teachers.Get(i), router.Get(0)));
    NetDeviceContainer adminRouter;
    for (uint32_t i = 0; i < admins.GetN(); i++)
        adminRouter.Add(p2p.Install(admins.Get(i), router.Get(0)));

    /* =======================
       4. IP ADDRESSING
    ======================= */
    Ipv4AddressHelper ip;
    ip.SetBase("10.1.1.0", "255.255.255.0"); ip.Assign(cloudRouter);
    ip.SetBase("10.1.2.0", "255.255.255.0"); ip.Assign(studentRouter);
    ip.SetBase("10.1.3.0", "255.255.255.0"); ip.Assign(teacherRouter);
    ip.SetBase("10.1.4.0", "255.255.255.0"); ip.Assign(adminRouter);
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    /* =======================
       5. TCP APPLICATION
    ======================= */
    uint16_t tcpPort = 8080;
    PacketSinkHelper tcpSink("ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), tcpPort));
    ApplicationContainer sinkApp = tcpSink.Install(cloud.Get(0));
    sinkApp.Start(Seconds(0.0));
    sinkApp.Stop(Seconds(20.0));

    BulkSendHelper tcpClient("ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address("10.1.1.1"), tcpPort));
    tcpClient.SetAttribute("MaxBytes", UintegerValue(0));
    for (uint32_t i = 0; i < students.GetN(); i++)
        tcpClient.Install(students.Get(i)).Start(Seconds(1 + i));
    for (uint32_t i = 0; i < teachers.GetN(); i++)
        tcpClient.Install(teachers.Get(i)).Start(Seconds(2 + i));
    for (uint32_t i = 0; i < admins.GetN(); i++)
        tcpClient.Install(admins.Get(i)).Start(Seconds(3 + i));

    /* =======================
       6. UDP APPLICATION
    ======================= */
    uint16_t udpPort = 9000;
    UdpEchoServerHelper udpServer(udpPort);
    ApplicationContainer udpServerApp = udpServer.Install(cloud.Get(0));
    udpServerApp.Start(Seconds(0.0));
    udpServerApp.Stop(Seconds(20.0));

    UdpEchoClientHelper udpClient(InetSocketAddress(Ipv4Address("10.1.1.1"), udpPort));
    udpClient.SetAttribute("MaxPackets", UintegerValue(5));
    udpClient.SetAttribute("Interval", TimeValue(Seconds(1)));
    udpClient.SetAttribute("PacketSize", UintegerValue(512));
    udpClient.Install(students.Get(0)).Start(Seconds(5));
    udpClient.Install(teachers.Get(0)).Start(Seconds(6));
    udpClient.Install(admins.Get(0)).Start(Seconds(7));

    /* =======================
       7. MOBILITY
    ======================= */
    MobilityHelper mobility;
    mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mobility.Install(students); mobility.Install(teachers);
    mobility.Install(admins); mobility.Install(cloud); mobility.Install(router);

    for (uint32_t i = 0; i < students.GetN(); i++)
        students.Get(i)->GetObject<MobilityModel>()->SetPosition(Vector(10, 20 + i * 15, 0));
    for (uint32_t i = 0; i < teachers.GetN(); i++)
        teachers.Get(i)->GetObject<MobilityModel>()->SetPosition(Vector(60, 20 + i * 15, 0));
    for (uint32_t i = 0; i < admins.GetN(); i++)
        admins.Get(i)->GetObject<MobilityModel>()->SetPosition(Vector(110, 20 + i * 15, 0));
    cloud.Get(0)->GetObject<MobilityModel>()->SetPosition(Vector(160, 40, 0));
    router.Get(0)->GetObject<MobilityModel>()->SetPosition(Vector(85, 40, 0));

    /* =======================
       8. NETANIM
    ======================= */
    AnimationInterface anim("smartschool_anim.xml");
    anim.UpdateNodeDescription(cloud.Get(0), "Cloud Server");
    anim.UpdateNodeDescription(router.Get(0), "Internet Router");
    for (uint32_t i = 0; i < students.GetN(); i++)
        anim.UpdateNodeDescription(students.Get(i), "Student " + std::to_string(i+1));
    for (uint32_t i = 0; i < teachers.GetN(); i++)
        anim.UpdateNodeDescription(teachers.Get(i), "Teacher " + std::to_string(i+1));
    for (uint32_t i = 0; i < admins.GetN(); i++)
        anim.UpdateNodeDescription(admins.Get(i), "Admin " + std::to_string(i+1));

    // Node Colors for visual distinction
    anim.UpdateNodeColor(cloud.Get(0), 0, 0, 255);       // Cloud: Blue
    anim.UpdateNodeColor(router.Get(0), 128, 128, 128); // Router: Gray
    for (uint32_t i = 0; i < students.GetN(); i++)
        anim.UpdateNodeColor(students.Get(i), 0, 255, 0);   // Students: Green
    for (uint32_t i = 0; i < teachers.GetN(); i++)
        anim.UpdateNodeColor(teachers.Get(i), 255, 165, 0); // Teachers: Orange
    for (uint32_t i = 0; i < admins.GetN(); i++)
        anim.UpdateNodeColor(admins.Get(i), 255, 0, 0);     // Admins: Red

    /* =======================
       9. FLOW MONITOR
    ======================= */
    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor = flowmon.InstallAll();

    /* =======================
       10. RUN SIMULATION
    ======================= */
    Simulator::Stop(Seconds(20));
    Simulator::Run();

    /* =======================
       11. EXPORT METRICS TO CSV
    ======================= */
    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();

    std::ofstream csvFile;
    csvFile.open("smartschool_metrics.csv");
    csvFile << "FlowId,Source,Destination,TxPackets,RxPackets,LostPackets,Throughput(Mbps),AvgDelay(s),AvgJitter(s)\n";

    for (auto const& flow : stats)
    {
        Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(flow.first);
        double throughput = flow.second.rxBytes * 8.0 / 1e6 / 20.0; // Mbps
        double avgDelay = flow.second.rxPackets ? flow.second.delaySum.GetSeconds() / flow.second.rxPackets : 0;
        double avgJitter = flow.second.rxPackets ? flow.second.jitterSum.GetSeconds() / flow.second.rxPackets : 0;

        csvFile << flow.first << ","
                << t.sourceAddress << ","
                << t.destinationAddress << ","
                << flow.second.txPackets << ","
                << flow.second.rxPackets << ","
                << flow.second.lostPackets << ","
                << throughput << ","
                << avgDelay << ","
                << avgJitter << "\n";
    }

    csvFile.close();
    Simulator::Destroy();
    return 0;
}
